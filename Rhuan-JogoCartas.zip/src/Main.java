import br.edu.uniritter.poo.controller.JogoController;
import br.edu.uniritter.poo.jogoDeCartas.view.JogadorView;
import br.edu.uniritter.poo.jogoDeCartas.view.JogoView;
import br.edu.uniritter.poo.jogoDeCartas.model.Baralho;
import br.edu.uniritter.poo.jogoDeCartas.model.Jogador;
import br.edu.uniritter.poo.jogoDeCartas.model.Lixo;

import java.util.ArrayList;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        JogoController controller =  new JogoController();
        controller.preJogo();
        controller.iniciaRodada();
       
    }
}
